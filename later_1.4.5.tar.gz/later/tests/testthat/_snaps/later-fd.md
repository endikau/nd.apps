# later_fd() errors when passed destroyed loops

    Code
      later_fd(identity, loop = loop)
    Condition
      Error:
      ! CallbackRegistry does not exist.

