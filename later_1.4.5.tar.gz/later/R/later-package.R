#' @keywords internal
"_PACKAGE"

## usethis namespace: start
#' @useDynLib later, .registration=TRUE
#' @importFrom Rcpp evalCpp
## usethis namespace: end
NULL
